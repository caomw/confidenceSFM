###########################
Structure from Motion (SFM)
###########################

dataRaw/ -> contains the behavioural results of the experiment

iViewXNao -> files that are used for the communication with the eye tracker. 

notes_meetings/  -> contains the parameters and ideas discussed in the meetigns with Megan and Nao.

srcPres/ -> SCRIPTS TO RUN THE EXPERIMENT:

		- 'initializeScreen.m': sets the default parameters to open the main window for the experiment.
		- 'setConstants.m' & 'setParamsSFM.m': adjust experimental parameters.
		- 'run_SFM.m': MAIN FILE. Runs the experiment.
